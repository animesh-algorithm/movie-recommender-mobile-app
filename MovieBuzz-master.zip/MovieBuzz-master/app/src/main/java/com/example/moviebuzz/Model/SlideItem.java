package com.example.moviebuzz.Model;

public class SlideItem {
    private  String image;

    public SlideItem(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
