package com.example.moviebuzz.Model;

public class SlideItemPosition {
    int position;

    public SlideItemPosition(int position) {
        this.position = position;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
